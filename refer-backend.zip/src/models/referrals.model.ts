import { Sequelize, DataTypes, Model, Optional } from 'sequelize';
import { Referral } from '@interfaces/referrals.interface';

export type ReferralCreationAttributes = Optional<
  Referral,
  | 'id'
  | 'candidate_user_id'
  | 'referrer_user_id'
  | 'is_requested_by_candidate'
  | 'is_referred'
  | 'job_url'
  | 'reasons_for_good_fit'
>;

export class ReferralModel extends Model<Referral, ReferralCreationAttributes> implements Referral {
  public id!: number;
  public candidate_user_id!: number;
  public referrer_user_id!: number;
  public is_requested_by_candidate!: boolean;
  public is_referred!: 'PENDING' | 'APPROVED' | 'REJECTED';
  public job_url?: string;
  public reasons_for_good_fit!: string;

  public readonly created_at?: Date;
  public readonly updated_at?: Date;
}

export default function (sequelize: Sequelize): typeof ReferralModel {
  ReferralModel.init(
    {
      id: {
        autoIncrement: true,
        primaryKey: true,
        type: DataTypes.BIGINT,
      },
      candidate_user_id: {
        type: DataTypes.BIGINT,
        allowNull: false,
      },
      referrer_user_id: {
        type: DataTypes.BIGINT,
        allowNull: false,
      },
      is_requested_by_candidate: {
        type: DataTypes.BOOLEAN,
        defaultValue: true,
      },
      is_referred: {
        type: DataTypes.ENUM('PENDING', 'APPROVED', 'REJECTED'),
        defaultValue: 'PENDING',
      },
      job_url: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      reasons_for_good_fit: {
        type: DataTypes.STRING,
        allowNull: false,
      },
    },
    {
      tableName: 'referrals',
      sequelize,
      timestamps: true,
    },
  );

  return ReferralModel;
}
