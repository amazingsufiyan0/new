import { Sequelize, DataTypes, Model } from 'sequelize';
import { EnvironmentVariable } from '@/interfaces/environment-variables.interface';

export class EnvironmentVariableModel extends Model<EnvironmentVariable> implements EnvironmentVariable {
  public max_otp_count!: number;
}

export default function (sequelize: Sequelize): typeof EnvironmentVariableModel {
  EnvironmentVariableModel.init(
    {
      max_otp_count: {
        type: DataTypes.INTEGER,
        defaultValue: 1,
      },
    },
    {
      tableName: 'environmentvariables',
      sequelize,
      timestamps: false,
    },
  );

  return EnvironmentVariableModel;
}
