import { Sequelize, DataTypes, Model } from 'sequelize';
import { UsersCompanies } from '@/interfaces/users-companies.interface';

export class UsersCompaniesModel extends Model<UsersCompanies> implements UsersCompanies {
  public id!: number;
  public user_id!: number;
  public company_id!: number;
}

export default function (sequelize: Sequelize): typeof UsersCompaniesModel {
  UsersCompaniesModel.init(
    {
      id: {
        autoIncrement: true,
        primaryKey: true,
        type: DataTypes.BIGINT,
      },
      user_id: {
        type: DataTypes.BIGINT,
        allowNull: false,
      },
      company_id: {
        type: DataTypes.BIGINT,
        allowNull: false,
      },
    },
    {
      tableName: 'usersCompanies',
      sequelize,
      timestamps: false,
    },
  );

  return UsersCompaniesModel;
}
