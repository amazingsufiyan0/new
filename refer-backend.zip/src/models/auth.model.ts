import { Sequelize, DataTypes, Model, Optional } from 'sequelize';
import { Auth } from '@interfaces/auth.interface';

export type AuthCreationAttributes = Optional<
  Auth,
  | 'id'
  | 'otp_count'
  | 'last_otp_generated_on'
  | 'is_verified'
  | 'is_disabled'
  | 'last_logged_in'
>;

export class AuthModel extends Model<Auth, AuthCreationAttributes> implements Auth {
  public id!: number;
  public user_id!: number;
  public otp_count!: number;
  public last_otp_generated_on?: Date;
  public is_verified!: boolean;
  public is_disabled!: boolean;
  public last_logged_in?: Date;
}

export default function (sequelize: Sequelize): typeof AuthModel {
  AuthModel.init(
    {
      id: {
        autoIncrement: true,
        primaryKey: true,
        type: DataTypes.BIGINT,
      },
      user_id: {
        type: DataTypes.BIGINT,
        allowNull: false,
      },
      otp_count: {
        type: DataTypes.INTEGER,
        defaultValue: 0,
      },
      last_otp_generated_on: {
        type: DataTypes.DATE,
        allowNull: true,
      },
      is_verified: {
        type: DataTypes.BOOLEAN,
        defaultValue: false,
      },
      is_disabled: {
        type: DataTypes.BOOLEAN,
        defaultValue: false,
      },
      last_logged_in: {
        type: DataTypes.DATE,
        allowNull: true,
      },
    },
    {
      tableName: 'auth',
      sequelize,
      timestamps: false,
    },
  );

  return AuthModel;
}
