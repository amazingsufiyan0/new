import { Sequelize, DataTypes, Model, Optional } from 'sequelize';
import { Company } from '@interfaces/companies.interface';

export type CompanyCreationAttributes = Optional<
  Company,
  | 'id'
  | 'name'
  | 'description'
  | 'hq_address'
  | 'no_of_employees'
  | 'logo_url'
  | 'sectors'
  | 'company_website_url'
  | 'careers_website_url'
  | 'consent_received'
>;

export class CompanyModel extends Model<Company, CompanyCreationAttributes> implements Company {
  public id!: number;
  public name!: string;
  public description!: string;
  public hq_address!: string;
  public no_of_employees!: number;
  public logo_url!: string;
  public sectors!: string;
  public company_website_url!: string;
  public careers_website_url!: string;
  public consent_received!: boolean;

  public readonly created_at?: Date;
  public readonly updated_at?: Date;
}

export default function (sequelize: Sequelize): typeof CompanyModel {
  CompanyModel.init(
    {
      id: {
        autoIncrement: true,
        primaryKey: true,
        type: DataTypes.BIGINT,
      },
      name: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      description: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      hq_address: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      no_of_employees: {
        type: DataTypes.BIGINT,
        allowNull: false,
      },
      logo_url: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      sectors: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      company_website_url: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      careers_website_url: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      consent_received: {
        type: DataTypes.BOOLEAN,
        defaultValue: false,
      },
    },
    {
      tableName: 'companies',
      sequelize,
      timestamps: true,
    },
  );

  return CompanyModel;
}
