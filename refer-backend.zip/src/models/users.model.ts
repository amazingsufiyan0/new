import { Sequelize, DataTypes, Model, Optional } from 'sequelize';
import { User } from '@interfaces/users.interface';

export type UserCreationAttributes = Optional<
  User,
  | 'id'
  | 'firstname'
  | 'lastname'
  | 'email'
  | 'role_id'
  | 'professional_title'
  | 'location'
  | 'bio'
  | 'current_company'
  | 'years_of_experience'
  | 'resume_url'
  | 'is_profile_completed'
  | 'is_verified'
>;

export class UserModel extends Model<User, UserCreationAttributes> implements User {
  public id!: number;
  public firstname!: string;
  public lastname!: string;
  public email!: string;
  public role_id!: number;
  public professional_title?: string;
  public location?: string;
  public bio?: string;
  public current_company?: string;
  public years_of_experience?: number;
  public resume_url?: string;
  public is_profile_completed!: boolean;
  public is_verified!: boolean;

  public readonly createdAt?: Date;
  public readonly updatedAt?: Date;
}

export default function (sequelize: Sequelize): typeof UserModel {
  UserModel.init(
    {
      id: {
        autoIncrement: true,
        primaryKey: true,
        type: DataTypes.BIGINT,
      },
      firstname: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      lastname: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      email: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true,
      },
      role_id: {
        type: DataTypes.BIGINT,
        allowNull: false,
      },
      professional_title: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      location: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      bio: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      current_company: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      years_of_experience: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      resume_url: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      is_profile_completed: {
        type: DataTypes.BOOLEAN,
        defaultValue: false,
      },
      is_verified: {
        type: DataTypes.BOOLEAN,
        defaultValue: false,
      },
    },
    {
      tableName: 'users',
      sequelize,
      timestamps: true,
    },
  );

  return UserModel;
}
