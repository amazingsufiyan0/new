export interface UsersCompanies {
  id: number;
  user_id: number;
  company_id: number;
}