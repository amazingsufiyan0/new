import { Request } from 'express';
import { User } from '@interfaces/users.interface';

export interface DataStoredInToken {
  id: number;
}

export interface TokenData {
  token: string;
  expiresIn: number;
}

export interface RequestWithUser extends Request {
  user: User;
}

export interface Auth {
  id: number;
  user_id: number;
  otp_count: number;
  last_otp_generated_on?: Date;
  is_verified: boolean;
  is_disabled: boolean;
  last_logged_in?: Date;
}