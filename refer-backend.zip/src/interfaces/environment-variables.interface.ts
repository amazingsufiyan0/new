export interface EnvironmentVariable {
  max_otp_count: number;
}