export interface Referral {
  id: number;
  candidate_user_id: number;
  referrer_user_id: number;
  is_requested_by_candidate: boolean;
  is_referred: 'PENDING' | 'APPROVED' | 'REJECTED';
  job_url?: string;
  reasons_for_good_fit: string;
}