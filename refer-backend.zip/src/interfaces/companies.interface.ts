export interface Company {
  id: number;
  name: string;
  description: string;
  hq_address: string;
  no_of_employees: number;
  logo_url: string;
  sectors: string;
  company_website_url: string;
  careers_website_url: string;
  consent_received: boolean;
}
