export interface User {
  id: number;
  firstname: string;
  lastname: string;
  email: string;
  role_id: number;
  professional_title?: string;
  location?: string;
  bio?: string;
  current_company?: string;
  years_of_experience?: number;
  resume_url?: string;
  is_profile_completed: boolean;
  is_verified: boolean;
}