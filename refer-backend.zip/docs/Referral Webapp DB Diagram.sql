CREATE TABLE "Companies" (
  "id" long PRIMARY KEY,
  "name" varchar,
  "description" varchar,
  "hq_address" varchar,
  "no_of_employees" varchar,
  "logo_url" varchar,
  "sectors" varchar,
  "company_website_url" varchar,
  "careers_website_url" varchar,
  "consent_received" boolean,
  "created_at" timestamp,
  "updated_at" timestamp
);

CREATE TABLE "UsersCompanies" (
  "id" long PRIMARY KEY,
  "user_id" long,
  "company_id" long
);

CREATE TABLE "Users" (
  "id" long PRIMARY KEY,
  "firstname" varchar,
  "lastname" varchar,
  "email" varchar,
  "role_id" long,
  "professional_title" varchar,
  "location" varchar,
  "bio" varchar,
  "current_company" varchar,
  "years_of_experience" integer,
  "resume_url" varchar,
  "is_profile_completed" boolean,
  "is_verified" boolean,
  "created_at" timestamp,
  "updated_at" timestamp
);

CREATE TABLE "Auth" (
  "id" long PRIMARY KEY,
  "user_id" long,
  "otp_count" integer,
  "last_otp_generated_on" datetime,
  "is_verified" boolean,
  "is_disabled" boolean,
  "last_logged_in" datetime
);

CREATE TABLE "Referrals" (
  "id" long PRIMARY KEY,
  "candidate_user_id" long,
  "referrer_user_id" long,
  "is_requested_by_candidate" boolean,
  "is_referred" enum,
  "job_url" long,
  "reasons_for_good_fit" varchar,
  "created_at" timestamp,
  "updated_at" timestamp
);

CREATE TABLE "EnvironmentVariables" (
  "max_otp_count" integer
);

ALTER TABLE "UsersCompanies" ADD FOREIGN KEY ("company_id") REFERENCES "Companies" ("id");

ALTER TABLE "UsersCompanies" ADD FOREIGN KEY ("user_id") REFERENCES "Users" ("id");

ALTER TABLE "Auth" ADD FOREIGN KEY ("user_id") REFERENCES "Users" ("id");

ALTER TABLE "Referrals" ADD FOREIGN KEY ("candidate_user_id") REFERENCES "Users" ("id");

ALTER TABLE "Referrals" ADD FOREIGN KEY ("referrer_user_id") REFERENCES "Users" ("id");
